part=["SiO2","Na2O","K2O","CaO","MgO","Al2O3","Fe2O3","CuO","PbO","BaO","P2O5","SrO","SnO2","SO2"]
sum,data=0,[]
for i in part:
    inp=float(input("请输入%s：" %i))
    data.append(inp)
    sum+=inp
print("归一结果为：（单位为%）")
for i in range(len(data)):
    data[i]=(data[i]/sum)*100
    print("%s: %.2f" %(part[i],data[i]))