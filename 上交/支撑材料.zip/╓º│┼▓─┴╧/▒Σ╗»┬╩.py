part=["SiO2","Na2O","K2O","CaO","MgO","Al2O3","Fe2O3","CuO","PbO","BaO","P2O5","SrO","SnO2","SO2"]
delta=[]
for i in part:
    inp=float(input("请输入风化前%s的比例：" %i))
    inp2=float(input("请输入风化后%s的比例：" % i))
    delta.append(((inp2-inp)/inp)*100)
print("变化率为：（单位为%）")
for i in range(len(part)):
    print("%s：%.2f" % (part[i], delta[i]))