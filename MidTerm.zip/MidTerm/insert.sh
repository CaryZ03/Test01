#!/bin/bash

python insert.py