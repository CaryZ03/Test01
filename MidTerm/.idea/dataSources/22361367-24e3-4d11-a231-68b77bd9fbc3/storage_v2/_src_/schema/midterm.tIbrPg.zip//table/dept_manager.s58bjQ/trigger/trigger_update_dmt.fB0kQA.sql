create definer = root@localhost trigger trigger_UPDATE_dmt
    after update
    on dept_manager
    for each row
BEGIN 
        UPDATE dept_manager_title SET from_date=NEW.from_date, to_date=NEW.to_date WHERE emp_no=NEW.emp_no; 
    END;

