create definer = root@localhost trigger trigger_insert_dmt
    after insert
    on dept_manager
    for each row
BEGIN 
        INSERT INTO dept_manager_title(emp_no, from_date, to_date) VALUES (NEW.emp_no, NEW.from_date, NEW.to_date); 
    END;

