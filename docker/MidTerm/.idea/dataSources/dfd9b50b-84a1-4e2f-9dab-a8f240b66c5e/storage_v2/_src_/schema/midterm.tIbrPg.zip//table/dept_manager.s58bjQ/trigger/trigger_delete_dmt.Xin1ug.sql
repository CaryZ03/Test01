create definer = caryz@`%` trigger trigger_delete_dmt
    after delete
    on dept_manager
    for each row
BEGIN 
        DELETE FROM dept_manager_title WHERE (emp_no, from_date, to_date)=(OLD.emp_no, OLD.from_date, OLD.to_date); 
    END;

